@extends('partials.app', ['title' => $title])

@section('content')
    <div class="col-span-12 space-y-6 xl:col-span-12">

        <x-toast />

        {{-- PAGE HEADER --}}
        <div class="flex flex-col gap-3 mb-6 sm:flex-row sm:items-center sm:justify-between px-3">
            <div>
                <h2 class="text-2xl font-semibold text-gray-800 dark:text-white/90">Sales</h2>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-0.5">All brick sale records</p>
            </div>
            <a href="{{ route('sales.create') }}"
                class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white rounded-lg bg-brand-500 hover:bg-brand-600 transition-colors shadow-theme-xs">
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="5" x2="12" y2="19" />
                    <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
                Add Sale
            </a>
        </div>

        {{-- TABLE CARD --}}
        <div class="rounded-2xl border border-gray-200 bg-white pt-4 dark:border-gray-800 dark:bg-white/[0.03]">

            {{-- TOOLBAR --}}
            <div class="mb-4 flex flex-col gap-3 px-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">All Sales</h3>
                    <p class="mt-0.5 text-theme-xs text-gray-500 dark:text-gray-400">
                        {{ $sales->total() }} sale{{ $sales->total() !== 1 ? 's' : '' }} found
                    </p>
                </div>

                <form method="GET" action="{{ route('sales.index') }}">
                    <div class="flex items-center gap-2">
                        <x-search-input placeholder="Search by sale..." />
                        <button type="submit"
                            class="inline-flex h-[42px] items-center gap-2 rounded-lg bg-brand-500 px-4 text-sm font-medium text-white shadow-theme-xs hover:bg-brand-600 transition-colors">
                            <svg class="fill-white" width="16" height="16" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M3.04199 9.37381C3.04199 5.87712 5.87735 3.04218 9.37533 3.04218C12.8733 3.04218 15.7087 5.87712 15.7087 9.37381C15.7087 12.8705 12.8733 15.7055 9.37533 15.7055C5.87735 15.7055 3.04199 12.8705 3.04199 9.37381ZM9.37533 1.54218C5.04926 1.54218 1.54199 5.04835 1.54199 9.37381C1.54199 13.6993 5.04926 17.2055 9.37533 17.2055C11.2676 17.2055 13.0032 16.5346 14.3572 15.4178L17.1773 18.2381C17.4702 18.531 17.945 18.5311 18.2379 18.2382C18.5308 17.9453 18.5309 17.4704 18.238 17.1775L15.4182 14.3575C16.5367 13.0035 17.2087 11.2671 17.2087 9.37381C17.2087 5.04835 13.7014 1.54218 9.37533 1.54218Z"
                                    fill="" />
                            </svg>
                            Search
                        </button>
                        @if (request('search'))
                            <a href="{{ route('sales.index') }}"
                                class="shadow-theme-xs flex h-[42px] items-center rounded-lg border border-gray-300 bg-white px-3.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03]">
                                Clear
                            </a>
                        @endif
                    </div>
                </form>
            </div>

            {{-- TABLE --}}
            <div class="custom-scrollbar max-w-full overflow-x-auto px-5 sm:px-6">
                <table class="min-w-full">
                    <thead class="border-y border-gray-100 py-3">
                        <tr>
                            <th class="py-3 pr-4 text-left text-theme-sm text-gray-500">#</th>
                            <th class="py-3 px-4 text-left text-theme-sm text-gray-500">Customer</th>
                            <th class="py-3 px-4 text-left text-theme-sm text-gray-500">Batch</th>
                            <th class="py-3 px-4 text-left text-theme-sm text-gray-500">Quantity</th>
                            <th class="py-3 px-4 text-left text-theme-sm text-gray-500">Rate/Brick</th>
                            <th class="py-3 px-4 text-left text-theme-sm text-gray-500">Total</th>
                            <th class="py-3 px-4 text-left text-theme-sm text-gray-500">Sale Date</th>
                            <th class="py-3 px-4 text-center text-theme-sm text-gray-500">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($sales as $index => $sale)
                            <tr class="hover:bg-gray-50 transition-colors">

                                <td class="py-3 pr-4 text-sm text-gray-500">
                                    {{ $sales->firstItem() + $index }}
                                </td>

                                <td class="py-3 px-4 text-sm text-gray-800 dark:text-white/90">
                                    {{ $sale->customer->name ?? '—' }}
                                </td>

                                <td class="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                                    {{ $sale->productionBatch->batch_no ?? '—' }}
                                </td>

                                <td class="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                                    {{ number_format($sale->quantity_sold) }}
                                    <span class="text-xs text-gray-400">bricks</span>
                                </td>

                                <td class="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                                    Rs {{ number_format($sale->rate_per_brick, 2) }}
                                </td>

                                <td class="py-3 px-4 text-sm font-medium text-green-600">
                                    Rs {{ number_format($sale->total, 2) }}
                                </td>

                                <td class="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                                    {{ \Carbon\Carbon::parse($sale->sale_date)->format('d M Y') }}
                                </td>

                                <td class="px-5 py-4 text-center">
                                    <div class="inline-flex items-center gap-1">
                                        <a href="{{ route('sales.edit', $sale->id) }}" title="Edit"
                                            class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-gray-500 hover:text-brand-500 hover:bg-brand-50 dark:text-gray-400 dark:hover:text-brand-400 dark:hover:bg-brand-500/10 transition-colors">
                                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                                                stroke-width="2">
                                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                                            </svg>
                                        </a>
                                    </div>
                                </td>

                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="py-16 text-center text-gray-500">No sales found</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            {{-- PAGINATION --}}
            <div class="border-t border-gray-200 px-6 py-4">
                {{ $sales->appends(request()->query())->links() }}
            </div>

        </div>
    </div>
@endsection
