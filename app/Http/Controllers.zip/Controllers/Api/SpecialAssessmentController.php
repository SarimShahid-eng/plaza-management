<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\SpecialAssessmentStoreRequest;
use App\Http\Requests\Api\SpecialAssessmentUpdateRequest;
use App\Http\Resources\Api\SpecialAssessmentCollection;
use App\Http\Resources\Api\SpecialAssessmentResource;
use App\Models\Plaza;
use App\Models\SpecialAssessment;
use App\Models\Unit;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class SpecialAssessmentController extends Controller
{
    public function index(Request $request): SpecialAssessmentCollection
    {
        $specialAssessments = SpecialAssessment::all();

        return new SpecialAssessmentCollection($specialAssessments);
    }

    public function store(SpecialAssessmentStoreRequest $request): SpecialAssessmentResource
    {
        $validated = $request->validated();
        $loggedInUser = request()->user();
        $validated['plaza_id'] = $loggedInUser->plaza_id;
        $getPlazaUnits = Plaza::find($loggedInUser->plaza_id)->where('unit_id', $loggedInUser->unit_id);
        // $required amount is what expense is costing means generator or other
        $required_per_unit = $validated['required_amount'] / $getPlazaUnits->count();
        $shortfall = $validated['required_amount'] - $getPlazaUnits->first()->master_pool_balance;
        $occupied_units = Unit::where('plaza_id', $loggedInUser->plaza_id)->where('status', 'Occupied')->count();
        $validated['per_unit_amount'] = $required_per_unit;
        $validated['shortfall'] = $shortfall;
        $validated['occupied_units'] = $occupied_units;
        $validated['created_by'] = $loggedInUser->id;

        $specialAssessment = SpecialAssessment::create($validated);

        return new SpecialAssessmentResource($specialAssessment);
    }

    // public function show(Request $request, SpecialAssessment $specialAssessment): Response
    // {
    //     return new SpecialAssessmentResource($specialAssessment);
    // }

    // public function update(SpecialAssessmentUpdateRequest $request, SpecialAssessment $specialAssessment): Response
    // {
    //     $specialAssessment->update($request->validated());

    //     return new SpecialAssessmentResource($specialAssessment);
    // }

    public function destroy(Request $request, SpecialAssessment $specialAssessment): Response
    {
        $specialAssessment->delete();

        return response()->noContent();
    }
}
