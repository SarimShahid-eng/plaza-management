<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\UnitPaidAmountStoreRequest;
use App\Http\Requests\Api\UnitStoreRequest;
use App\Http\Requests\Api\UnitUpdateRequest;
use App\Http\Resources\Api\UnitResource;
use App\Models\MonthlyDue;
use App\Models\Payment;
use App\Models\PlazaSetting;
use App\Models\Unit;
use App\Models\UnitPaymentHistory;
use App\Models\User;
use App\Services\PaymentService;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UnitController extends Controller
{
    private PaymentService $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    public function index(Request $request)
    {
        $loggedInUserPlazaId = request()->user()->plaza_id;
        $query = Unit::where('plaza_id', $loggedInUserPlazaId)->with('histories');
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('unit_number', 'like', "%{$search}%")
                    ->orWhereHas('resident', function ($sub) use ($search) {
                        $sub->where('full_name', 'like', "%{$search}%");
                    });
            });
        }
        if ($request->filled('status')) {
            $status = $request->input('status');
            $query->whereHas('latestHistory', function ($q) use ($status) {
                $q->where('status', $status);
            });

        }
        $perPage = min($request->input('perPage', 10), 1000);
        $units = $query->paginate($perPage)->through(function ($item) {
            return [
                'id' => $item->id,
                'unit_number' => $item->unit_number,
                'floor' => $item->floor,
                'user' => $item->resident->full_name ?? null,
                'status' => $item->status,
                // 'latestStatus' => $item->latestHistory ? [
                //     'id' => $item->latestHistory->id,
                //     'status' => $item->latestHistory->status,
                //     'notes' => $item->latestHistory->notes,
                //     'date' => $item->latestHistory->created_at->format('d M, Y'),
                //     'changed_by' => $item->latestHistory->changed_by,
                // ] : null,

                // 'histories' => $item->histories->map(function ($history) {
                //     return [
                //         'id' => $history->id,
                //         'status' => $history->status,
                //         'notes' => $history->notes,
                //         'date' => $history->created_at->format('d M, Y'),
                //         'changed_by' => $history->changed_by,
                //     ];
                // }),
            ];
        });

        return response()->json([
            'units' => $units,
        ], 200);
    }

    public function store(UnitStoreRequest $request)
    {
        $validated = $request->validated();
        $loggedInUser = $request->user(); // Correctly grabbing the user object
        $lastUnit = Unit::where('plaza_id', $loggedInUser->plaza_id)
            ->where('unit_number', 'like', $validated['prefix'].'-%')
            ->orderByDesc('id') // or unit_number if properly formatted
            ->first();

        if ($lastUnit) {
            // Extract number from "ABC-10"
            $lastNumber = (int) explode('-', $lastUnit->unit_number)[1];
        } else {
            $lastNumber = 0;
        }
        // Use a transaction to ensure all-or-nothing data integrity
        $units = DB::transaction(function () use ($validated, $loggedInUser, $lastNumber) {

            $unitModels = collect()->times($validated['count'], function ($i) use ($validated, $loggedInUser, $lastNumber) {
                $sequenceNumber = $lastNumber + $i;

                $unit = Unit::create([
                    'plaza_id' => $loggedInUser->plaza_id,
                    'unit_number' => $validated['prefix'].'-'.$sequenceNumber,
                    'floor' => $validated['floor'] ?? null,
                    'monthly_dues_amount' => $this->getMonthlyDuesByPlazaUnit(),
                    'due' => 0,
                ]);

                return $unit;
            });

            return new EloquentCollection($unitModels);
        });

        return UnitResource::collection($units);

    }

    private function getMonthlyDuesByPlazaUnit()
    {
        // $request = new Request;
        $loggedInUser = request()->user();
        // dd($loggedInUser);
        $plazaFees = PlazaSetting::where('plaza_id', $loggedInUser->plaza_id)->first()->monthly_dues_amount;

        return $plazaFees;
    }

    public function show(Request $request, Unit $unit): UnitResource
    {
        // 1. Load the relationship to avoid N+1 and ensure history shows up
        $unit->load(['histories', 'resident']);

        return new UnitResource($unit);
    }

    public function update(UnitUpdateRequest $request): UnitResource
    {
        $validated = $request->validated();

        $unit = Unit::findOrFail($validated['unit_id']);

        DB::transaction(function () use ($unit, $validated, $request) {
            $unit->update($validated);
            if (isset($validated['status'])) {
                $unit->histories()->create([
                    'user_id' => $validated['user_id'],
                    'plaza_id' => $request->user()->plaza_id,
                    'status' => $validated['status'] ?? 'Occupied',
                    'notes' => 'Status updated via API',
                    'changed_by' => $request->user()->id,
                ]);
            }
        });

        return new UnitResource($unit->load('histories'));
    }

    public function destroy(Unit $unit): Response
    {
        $unit->delete();

        return response()->noContent();
    }

    public function paidAmount(UnitPaidAmountStoreRequest $request)
    {
        // get current amount fined by admin;
        $validated = $request->validate();

        $unit = Unit::find($validated['unit_id']);
        // if last month remaining amount exist than that amount-current coming coming amount else monthly dues - current coming amount= remaining amount
        $latestRemaining = MonthlyDue::where('unit_id', $validated['unit_id'])->latest('id')->first();
        $monthlyDuesAmount = $unit->monthly_dues_amount;
        $latestRemainingCurrent = $latestRemaining ? $$latestRemaining->remaining_amount : $monthlyDuesAmount;
        $remainingAmount = $latestRemainingCurrent - $validated['amount'];
        if ($remainingAmount <= 0) {
            $status = 'Paid';
        } elseif ($remainingAmount < $monthlyDuesAmount) {
            $status = 'Partial';
        } else {
            $status = 'Unpaid';
        }

        if ($validated['amount_type'] === 'monthly') {
            // tracks payment amount
            $monthlyDue = MonthlyDue::firstOrCreate(
                [
                    'unit_id' => $validated['unit_id'],
                    'plaza_id' => $request->user()->plaza_id,
                    'month' => now()->format('Y-m'),
                ],
                [
                    'monthly_amount' => $monthlyDuesAmount,
                    'paid_amount' => 0,
                    'remaining_amount' => $monthlyDuesAmount,
                    'status' => 'UNPAID',
                    'due_date' => now()->addMonth()->day(15),
                ]
            );

            // Update if already exists
            $monthlyDue->increment('paid_amount', $validated['amount']);
            $remainingAmount = $monthlyDue->monthly_amount - $monthlyDue->paid_amount;
            $monthlyDue->update([
                'remaining_amount' => max(0, $remainingAmount),
                'status' => $remainingAmount <= 0 ? 'Paid' : ($monthlyDue->paid_amount > 0 ? 'Partial' : 'Unpaid'),
                'payment_date' => now(),
            ]);

            // Create Payment record
            Payment::create([
                'unit_id' => $validated['unit_id'],
                'plaza_id' => $request->user()->plaza_id,
                'monthly_due_id' => $monthlyDue->id,
                'amount' => $validated['amount'],
                // 'payment_type' => $validated['payment_type'], // Cash, Bank Transfer, etc.
                'payment_type' => 'Cash', // Cash, Bank Transfer, etc.
                'reference' => $validated['reference'] ?? null,
                'logged_by' => $request->user()->id,
            ]);

            $unit->update(['due' => max(0, $remainingAmount)]);

        } elseif ('amount_type' === 'assesment') {
            // audit_logs
            $assessment = UnitPaymentHistory::where('unit_id', $validated['unit_id'])
                ->where('assessment_id', $validated['assessment_id'])
                ->first();
            $remainingAmount = $assessment->remaining_amount - $validated['amount'];

            if ($remainingAmount <= 0) {
                $status = 'Paid';
            } elseif ($remainingAmount < $assessment->assessed_amount) {
                $status = 'Partial';
            } else {
                $status = 'Unpaid';
            }

            $assessment->update([
                'paid_amount' => $assessment->paid_amount + $validated['amount'],
                'remaining_amount' => max(0, $remainingAmount),
                'status' => $status,
                'payment_date' => now(),
            ]);
            $totalRemaining = MonthlyDue::forUnit($validated['unit_id'])
                ->whereIn('status', ['UNPAID', 'PARTIAL', 'OVERDUE'])
                ->sum('remaining_amount') +
                             UnitPaymentHistory::forUnit($validated['unit_id'])
                                 ->whereIn('status', ['UNPAID', 'PARTIAL', 'OVERDUE'])
                                 ->sum('remaining_amount');

            $unit->update(['due' => $totalRemaining]);
        }
        $this->paymentService->recordTransaction(
            plazaId: $request->user()->plaza_id,
            type: 'credit',
            amount: $validated['amount'],
            description: 'Monthly dues payment',
            userId: $request->user()->id
        );

        return response()->json(['success' => true, 'unit' => $unit]);

    }

    public function assignMember(Request $request)
    {
        $validated = $request->validate(
            [
                'unit_id' => 'required',
                'full_name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email',
                'password' => ['required', 'confirmed', 'min:8'],
                'phone_number' => 'required|min:11|max:13',
            ],
            [
                'full_name.required' => 'Please enter the user\'s full name.',
                'email.required' => 'An email address is required.',
                'email.email' => 'Please enter a valid email address.',
                'email.unique' => 'This email is already registered.',
                'password.required' => 'A password is required.',
                'password.confirmed' => 'The password confirmation does not match.',
                'password.min' => 'Password must be at least 8 characters.',
                'phone_number.required' => '',
            ]
        );
        $validated['role'] = 'member';
        $validated['plaza_id'] = $request->user()->plaza_id;
        $validated['password'] = Hash::make($validated['password']);

        $user = User::create($validated);
        // email,password
        if ($user->role != 'member') {
            return response()->json([
                'message' => 'Assign user must be a member'], 422);
        }
        $unit = Unit::findOrFail($validated['unit_id']);
        $unit->update([
            'user_id' => $user->id,
            'status' => 'Occupied',
            'due' => $this->getMonthlyDuesByPlazaUnit(),
        ]);

        $unit->histories()->create([
            'plaza_id' => $request->user()->plaza_id,
            'user_id' => $user->id,
            'move_in' => now(),
            'notes' => 'assigning member',
            'changed_by' => $request->user()->id,
        ]);

        return response()->json([
            'message' => 'Memeber On Board Successfully',
            'unit' => new UnitResource($unit->load(['resident'])),
        ], 200);
    }

    public function revokeMember(Request $request)
    {
        $validate = $request->validate([
            'user_id' => 'required|exists:users,id',
            'unit_id' => 'required|exists:units,id',
        ]);
        $unit = Unit::find($validate['unit_id']);

        $unit->histories()->create([
            'plaza_id' => $request->user()->plaza_id,
            'user_id' => $validate['user_id'],
            'move_out' => now(),
            'due_at_checkout' => $unit->due,
            'notes' => 'moving out member',
            'changed_by' => $request->user()->id,
        ]);

        $unit->update([
            'user_id' => $validate['user_id'],
            'status' => 'Vacant',
            'due' => 0,
        ]);

        return response()->json([
            'message' => 'Member Moved Out Successfully',
            'unit' => new UnitResource($unit->load(['resident'])),
        ], 200);
    }
}
