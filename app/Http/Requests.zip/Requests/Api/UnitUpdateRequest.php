<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class UnitUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {

        return [
            // 'prefix' => ['required'],
            // 'count' => ['required', 'integer'],
            'status' => ['required', 'in:Occupied,Vacant'],
            'floor' => ['nullable', 'integer'],
            'user_id' => ['required', 'integer'],
            'unit_id' => ['required', 'integer', 'exists:units,id'],

        ];
    }
}
