<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class UnitPaidAmountStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'unit_id' => ['required', 'integer', 'exists:units,id'],
            'amount' => ['required', 'integer'],
            'amount_type' => ['required', 'in:assesment,monthly'],
            'assesment_id'=>['required_if:amount_type,assesment']
        ];
    }
    public function messages(): array
    {
        return [
            'unit_id.required' => "unit must be provided",
            'assesment_id.required_if' => ['assesment must be provided when type is assesment'],
        ];
    }
}
